/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author codeboy1028
 */
public class ArbolGeneral {

    NodoGeneral raiz;

    public ArbolGeneral() {
        raiz = null;
    }

    public boolean insertar(char dato, String path) {
        if (raiz == null) {
            raiz = new NodoGeneral(dato);
            return raiz != null;
        }

        if (path.isEmpty()) {
            return false;
        }

        NodoGeneral padre = buscarNodoRecursivo(path);
        if (padre == null) {
            return false;
        }

        NodoGeneral hijoYaExiste = buscarNodoRecursivo(path + "/" + dato);
        if (hijoYaExiste != null) {
            return false;
        }

        NodoGeneral nuevo = new NodoGeneral(dato);
        return padre.enlazar(nuevo);
    }

    private NodoGeneral buscarNodo(String path) {
        path = path.substring(1);
        String vector[] = path.split("/");
        if (vector[0].charAt(0) == raiz.dato) {
            if (vector.length == 1) {
                return raiz;
            }
            NodoGeneral padre = raiz;
            for (int i = 1; i < vector.length; i++) {
                padre = padre.obtenerHijo(vector[i].charAt(0));
                if (padre == null) {
                    return padre;
                }
            }
            return padre;
        }

        return null;
    }
    
    
    
    public boolean eliminar (String path){
        
        if (raiz == null){
            return false;
        }
        
        NodoGeneral hijo = buscarNodo (path);
        
        if (hijo == null){
            return false;
        }
        
        if (!hijo.esHoja()){
            
            return false;
        }
        
        if (hijo == raiz){
            raiz = null;
            return true;
        }
        
        String pathPadre = obtenerPathPadre(path);
        
        NodoGeneral padre = buscarNodo(pathPadre);
        
        return padre.desenlazar(hijo);
        
    }

    private String obtenerPathPadre(String path) {
        
        int posicionAntesUltimaDiagonal = path.lastIndexOf("/")-1;
        
        return path.substring(0,posicionAntesUltimaDiagonal);
    }
    
    private NodoGeneral buscarNodoRecursivo(NodoGeneral encontrado, String array[], int aux){
        if(aux < array.length){      
            encontrado = encontrado.obtenerHijo(array[aux].charAt(0));
            if(encontrado == null){
                return null;
            }
            
            aux++;
            
            encontrado = buscarNodoRecursivo(encontrado, array, aux);
        }
        return encontrado;
    }
    
     private NodoGeneral buscarNodoRecursivo(String path){
        
         /*if(path.isEmpty())
        {
         return nodoEncontrado;
        }*/
        
         
        path = path.substring(1);
        
        String array[];
        array = path.split("/");
        
        int aux = 1;
        
        if(array[0].charAt(0) == raiz.dato)
        {
            if (array.length == aux)
            {
                return raiz;
            }
            
            NodoGeneral encontrado = raiz;
            
            return buscarNodoRecursivo(encontrado, array, aux);
        }
        
        return null;
    }
     
     public String mostrarHijosRaiz(){
         if(raiz == null){
            return"ERROR: No existe raiz";
        }
         if(raiz.ini == null){
             return "ERROR: No existe nodos en raiz";
         }
          String cad="Raiz:"+raiz.dato+"\n";
          for(NodoHijo temp = raiz.ini; temp != null; temp= temp.sig){
              cad+=""+temp.direccionHijo.dato+"\n";
          }
          return cad;
     }
     
     public String mostrarHijosNodo(String path){
         NodoGeneral padre = buscarNodo(path);
         if(padre == null){
             return "Error: No existe NodoPadre";
         }
         if(padre.ini ==null){
             return "Es hoja";
         }
         String cad="";
         for(NodoHijo temp = padre.ini; temp != null; temp = temp.sig){
         cad+=""+temp.direccionHijo.dato+","; 
     }
         return cad;
     }

}
